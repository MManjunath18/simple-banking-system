import os
from tkinter import *
from tkinter import messagebox, scrolledtext
from datetime import datetime

USERS_DIR = "users"
if not os.path.exists(USERS_DIR):
    os.makedirs(USERS_DIR)

def get_user_file(username):
    return os.path.join(USERS_DIR, f"{username}.txt")

def create_account():
    username = entry_username.get()
    if not username:
        messagebox.showwarning("Warning", "Enter a username.")
        return
    filepath = get_user_file(username)
    if os.path.exists(filepath):
        messagebox.showinfo("Info", "Account already exists.")
    else:
        with open(filepath, "w") as f:
            f.write("Balance: 0\n")
        messagebox.showinfo("Success", f"Account created for {username}.")

def deposit():
    username = entry_username.get()
    amount = entry_amount.get()
    if not username or not amount:
        messagebox.showwarning("Warning", "Enter both username and amount.")
        return
    try:
        amount = float(amount)
    except ValueError:
        messagebox.showerror("Error", "Invalid amount.")
        return
    filepath = get_user_file(username)
    if not os.path.exists(filepath):
        messagebox.showerror("Error", "Account does not exist.")
        return
    with open(filepath, "r+") as f:
        lines = f.readlines()
        balance = float(lines[0].split(":")[1].strip())
        balance += amount
        lines[0] = f"Balance: {balance}\n"
        f.seek(0)
        f.writelines(lines)
        f.write(f"Deposit {amount} on {datetime.now()}\n")
    messagebox.showinfo("Success", f"Deposited {amount}.")

def withdraw():
    username = entry_username.get()
    amount = entry_amount.get()
    if not username or not amount:
        messagebox.showwarning("Warning", "Enter both username and amount.")
        return
    try:
        amount = float(amount)
    except ValueError:
        messagebox.showerror("Error", "Invalid amount.")
        return
    filepath = get_user_file(username)
    if not os.path.exists(filepath):
        messagebox.showerror("Error", "Account does not exist.")
        return
    with open(filepath, "r+") as f:
        lines = f.readlines()
        balance = float(lines[0].split(":")[1].strip())
        if amount > balance:
            messagebox.showerror("Error", "Insufficient funds.")
            return
        balance -= amount
        lines[0] = f"Balance: {balance}\n"
        f.seek(0)
        f.writelines(lines)
        f.write(f"Withdraw {amount} on {datetime.now()}\n")
    messagebox.showinfo("Success", f"Withdrew {amount}.")

def view_balance():
    username = entry_username.get()
    filepath = get_user_file(username)
    if not os.path.exists(filepath):
        messagebox.showerror("Error", "Account does not exist.")
        return
    with open(filepath, "r") as f:
        balance = f.readline().strip()
    messagebox.showinfo("Balance", balance)

def view_history():
    username = entry_username.get()
    filepath = get_user_file(username)
    if not os.path.exists(filepath):
        messagebox.showerror("Error", "Account does not exist.")
        return
    with open(filepath, "r") as f:
        history_text.delete(1.0, END)
        history_text.insert(END, f.read())

# GUI layout
root = Tk()
root.title("Bank Transaction System")

Label(root, text="Username:").grid(row=0, column=0, padx=10, pady=5, sticky="e")
entry_username = Entry(root, width=20)
entry_username.grid(row=0, column=1)

Label(root, text="Amount:").grid(row=1, column=0, padx=10, pady=5, sticky="e")
entry_amount = Entry(root, width=20)
entry_amount.grid(row=1, column=1)

Button(root, text="Create Account", width=20, command=create_account).grid(row=2, column=0, pady=5)
Button(root, text="Deposit", width=20, command=deposit).grid(row=2, column=1, pady=5)
Button(root, text="Withdraw", width=20, command=withdraw).grid(row=3, column=0, pady=5)
Button(root, text="View Balance", width=20, command=view_balance).grid(row=3, column=1, pady=5)
Button(root, text="View History", width=42, command=view_history).grid(row=4, column=0, columnspan=2, pady=5)

history_text = scrolledtext.ScrolledText(root, width=50, height=10)
history_text.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

root.mainloop()